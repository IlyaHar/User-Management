<?php

return [
    'driver' => 'mysql',
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'UserManagement',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8'
];