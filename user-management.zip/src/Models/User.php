<?php

namespace App\Models;

use App\Kernel\Database\Model;

class User extends Model
{
}