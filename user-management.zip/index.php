<?php
const APP_DIR = __DIR__;

require_once APP_DIR . '/vendor/autoload.php';

$app = new \App\Kernel\Container\Container();

